import React,{Component} from 'react';
import AdminNavbar from "../../components/admin/AdminNavbar";

class ViewPosts extends Component{
    render(){
        return(
                <AdminNavbar/>
           
        )
    }
}

export default ViewPosts;