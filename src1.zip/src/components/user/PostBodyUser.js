import React, { Component } from 'react';
import PostComponentUser from './PostComponentUser';
export default class PostBodyUser extends Component {
  render() {
    return (
        <div style={{width:'1100px'}}>
            <PostComponentUser></PostComponentUser>
        </div>
    )
  }
}
