All image files go here
